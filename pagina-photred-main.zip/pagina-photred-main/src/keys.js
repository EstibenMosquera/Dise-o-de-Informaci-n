module.exports = {
    database:{
        URI:'mongodb://localhost/dbphotred'
    }
}